export default class InsufficientMoneyException extends Error {
    constructor() {
        super('Insufficient funds in the account');
    }
}