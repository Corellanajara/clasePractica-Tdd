import Bank from './Bank'; // Importa la clase Bank desde el archivo correspondiente
import InsufficientMoneyException from '../exceptions/InsufficientMoneyException'; // Importa la clase InsufficientMoneyException desde el archivo correspondiente
import BigDecimal from 'js-big-decimal'; // Importa la clase BigDecimal si es necesario

export default class Account {
    private person: string;
    private balance: BigDecimal;
    private bank: Bank | null;

    constructor(person: string, balance: BigDecimal) {
        this.person = person;
        this.balance = balance;
        this.bank = null;
    }

    getPerson(): string {
        return this.person;
    }

    getBalance(): BigDecimal {
        return this.balance;
    }

    getBank(): Bank | null {
        return this.bank;
    }

    setBank(bank: Bank): void {
        this.bank = bank;
    }

    debit(amount: BigDecimal): void {
        const newBalance = this.balance.subtract(amount);
        const zero = new BigDecimal('0');
        if (newBalance.compareTo(zero) < 0) {
            throw new InsufficientMoneyException();
        }
        this.balance = newBalance;
    }

    credit(amount: BigDecimal): void {
        this.balance = this.balance.add(amount);
    }
}