import Account from './Account'; // Importa la clase Account desde el archivo correspondiente
import BigDecimal from 'js-big-decimal'; // Importa la clase BigDecimal si es necesario

export default class Bank {
    private name?: string;
    private accounts: Account[] = [];

    constructor(name?: string) {
        this.name = name;
    }

    getName(): string | undefined {
        return this.name;
    }

    setName(name: string): void {
        this.name = name;
    }

    getAccounts(): Account[] {
        return this.accounts;
    }

    transfer(source: Account, destination: Account, amount: BigDecimal): void {
        source.debit(amount);
        destination.credit(amount);
    }

    addAccount(account: Account): void {
        this.accounts.push(account);
        account.setBank(this);
    }
}
