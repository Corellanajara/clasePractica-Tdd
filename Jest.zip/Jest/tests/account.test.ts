import Account from '../src/domain/Account';
import Bank from '../src/domain/Bank';
import InsufficientMoneyException from '../src/exceptions/InsufficientMoneyException';
import BigDecimal from 'js-big-decimal';
import 'jest';

describe('Account Tests', () => {
    test('testAccountNameIsValid', () => {
        // Arrange
        const account = new Account('John', new BigDecimal('1000.00'));

        // Act & Assert
        expect(account.getPerson()).not.toBeNull();
        expect(account.getPerson()).toBe('John');
        expect(account.getPerson().length).toBe(4);
    });

    test('testAccountBalance', () => {
        // Arrange
        const initialBalance = new BigDecimal('1000.00');
        const account = new Account('John', initialBalance);

        // Act & Assert        
        expect(account.getBalance()).not.toBeNull();
        expect(account.getBalance()).toBe(initialBalance);
        expect(account.getBalance().compareTo(new BigDecimal('0'))).toBeTruthy();
    });

    test('testDebitAccount', () => {
        // Arrange
        const initialBalance = new BigDecimal('1000.00');
        const account = new Account('John', initialBalance);

        // Act
        const debitAmount = new BigDecimal('100.00');
        account.debit(debitAmount);

        // Assert
        const expectedBalance = initialBalance.subtract(debitAmount);
        expect(account.getBalance()).toEqual(expectedBalance);
    });

    test('testCreditAccount', () => {
        // Arrange
        const initialBalance = new BigDecimal('1000.00');
        const account = new Account('John', initialBalance);

        // Act
        const creditAmount = new BigDecimal('100.00');
        account.credit(creditAmount);

        // Assert
        const expectedBalance = initialBalance.add(creditAmount);
        expect(account.getBalance()).toEqual(expectedBalance);
    });

    test('testInsufficientMoneyException', () => {
        // Arrange
        const initialBalance = new BigDecimal('1000.00');
        const account = new Account('John', initialBalance);

        // Act & Assert
        expect(() => {
            account.debit(new BigDecimal('1500.00'));
        }).toThrow(InsufficientMoneyException);
    });

    test('testTransferMoneyBetweenAccounts', () => {
        // Arrange
        const initialBalance1 = new BigDecimal('5000.00');
        const account1 = new Account('John', initialBalance1);

        const initialBalance2 = new BigDecimal('1000.00');
        const account2 = new Account('Doe', initialBalance2);

        const bank = new Bank();
        bank.setName('Banco de Chile');

        // Act
        const transferAmount = new BigDecimal('500.00');
        bank.transfer(account1, account2, transferAmount);

        // Assert
        expect(account1.getBalance()).toEqual(new BigDecimal('4500.00'));
        expect(account1.getBalance()).toEqual(initialBalance1.subtract(transferAmount));
        expect(account2.getBalance()).toEqual(new BigDecimal('1500.00'));
        expect(account2.getBalance()).toEqual(initialBalance2.add(transferAmount));
    });

    test('testAccountBankRelationship', () => {
        // Arrange
        const initialBalance1 = new BigDecimal('5000.00');
        const account1 = new Account('John', initialBalance1);

        const initialBalance2 = new BigDecimal('1000.00');
        const account2 = new Account('Doe', initialBalance2);

        const bank = new Bank();
        bank.setName('Banco de Chile');
        bank.addAccount(account1);
        bank.addAccount(account2);

        // Act
        bank.transfer(account1, account2, new BigDecimal('500.00'));

        // Assert
        expect(account1.getBalance()).toEqual(new BigDecimal('4500.00'));
        expect(account2.getBalance()).toEqual(new BigDecimal('1500.00'));

        expect(bank.getAccounts().length).toBe(2);
        expect(account1.getBank()?.getName()).toBe('Banco de Chile');
        expect(account2.getBank()?.getName()).toBe('Banco de Chile');
        const johnAccount = bank.getAccounts().find(account => account.getPerson() === 'John');
        expect(johnAccount?.getPerson()).toBe('John');
        expect(bank.getAccounts().some(account => account.getPerson() === 'John')).toBe(true);
        expect(bank.getAccounts().some(account => account.getPerson() === 'Doe')).toBe(true);
    });

    test('testBankAccountRelationshipAll', () => {
        // Arrange
        const account1 = new Account('John', new BigDecimal('5000.00'));
        const account2 = new Account('Doe', new BigDecimal('1000.00'));

        const bank = new Bank();
        bank.setName('Banco de Chile');
        bank.addAccount(account1);
        bank.addAccount(account2);

        // Act
        bank.transfer(account1, account2, new BigDecimal('500.00'));

        // Assert
        expect(account1.getBalance()).toEqual(new BigDecimal('4500.00'));
        expect(account2.getBalance()).toEqual(new BigDecimal('1500.00'));
        expect(bank.getAccounts().length).toBe(2);
        expect(account1.getBank()?.getName()).toBe('Banco de Chile');
        expect(account2.getBank()?.getName()).toBe('Banco de Chile');

        const johnAccount = bank.getAccounts().find(account => account.getPerson() === 'John');
        expect(johnAccount?.getPerson()).toBe('John');

        expect(bank.getAccounts().some(account => account.getPerson() === 'John')).toBe(true);
        expect(bank.getAccounts().some(account => account.getPerson() === 'Doe')).toBe(true);
    });

    test.skip('testAccountBankRelationshipWithAssertAll2', () => {
        // Arrange
        const initialBalance1 = new BigDecimal('5000.00');
        const account1 = new Account('John', initialBalance1);

        const initialBalance2 = new BigDecimal('1000.00');
        const account2 = new Account('Mary', initialBalance2);

        const bank = new Bank();
        bank.setName('Banco de Chile');

        bank.addAccount(account1);
        bank.addAccount(account2);

        // Act
        bank.transfer(account1, account2, new BigDecimal('500.00'));

        // Assert
        // La prueba está deshabilitada temporalmente
    }); 
});
