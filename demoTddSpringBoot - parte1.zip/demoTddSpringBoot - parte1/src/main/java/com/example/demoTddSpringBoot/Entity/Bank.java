package com.example.demoTddSpringBoot.Entity;

import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Data
public class Bank {
    private String name;

    private List<Account> accounts = new ArrayList<>();

    public void transfer(Account source, Account destination, BigDecimal amount) {
        source.debit(amount);
        destination.credit(amount);
    }

    public void addAccount(Account account) {
        accounts.add(account);
        account.setBank(this);
    }
}
