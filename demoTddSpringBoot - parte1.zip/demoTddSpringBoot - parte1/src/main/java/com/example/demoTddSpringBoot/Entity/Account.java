package com.example.demoTddSpringBoot.Entity;

import com.example.demoTddSpringBoot.Exceptions.InsufficientMoneyException;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class Account {
    private String person;
    private BigDecimal balance;
    private Bank bank;

    public Account(String person, BigDecimal balance) {
        this.person = person;
        this.balance = balance;
    }

    public void debit(BigDecimal amount) {
        BigDecimal newBalance = this.balance.subtract(amount);
        if (newBalance.compareTo(BigDecimal.ZERO) < 0) {
            throw new InsufficientMoneyException("Insufficient funds in the account");
        }
        this.balance = newBalance;
    }

    public void credit(BigDecimal amount) {
        this.balance = this.balance.add(amount);
    }
}
