package com.example.demoTddSpringBoot.Entity;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeTrue;
import static org.junit.jupiter.api.Assumptions.assumingThat;

class AccountTest2 {
    Account account;

    @BeforeAll
    static void beforeAll() {
        System.out.println("Initializing the test\n");
    }

    @BeforeEach
    void initTestMethod() {
        BigDecimal initialBalance = new BigDecimal("1000.00");
        this.account = new Account("John", initialBalance);
        System.out.println("starting test method\n");
    }

    @AfterEach
    void tearDown() {
        System.out.println("finishing test method");
    }

    @AfterAll
    static void afterAll() {
        System.out.println("Finishing the test");
    }


    @Test
    @EnabledOnOs(OS.WINDOWS)
    void testOnlyOnWindows() {
    }

    @Test
    @DisabledOnOs(OS.WINDOWS)
    void testNotOnWindows() {
    }

    @Test
    @EnabledOnJre(JRE.JAVA_8)
    void testOnlyOnJDK8() {
    }

    @Test
    @EnabledOnJre(JRE.JAVA_20)
    void testSoloJDK20() {
    }

    @Test
    @DisabledOnJre(JRE.JAVA_20)
    void testNoJDK20() {
    }

    @Test
    void printSystemProperties() {
        Properties properties = System.getProperties();
        properties.forEach((k, v) -> System.out.println(k + ": " + v));
    }

    @Test
    @EnabledIfSystemProperty(named = "java.specification.version", matches = "20")
    void testJavaVersion() {
    }

    @Test
    @EnabledIfSystemProperty(named = "os.arch", matches = ".*64.*")
    void testSoloAmd64() {
    }

    @Test
    @DisabledIfSystemProperty(named = "os.arch", matches = ".*64.*")
    void testNoAmd64() {
    }

    @Test
    void printEnvironmentVariables() {
        Map<String, String> getenv = System.getenv();
        getenv.forEach((k, v) -> System.out.println(k + ": " + v));
    }

    @Test
    @EnabledIfEnvironmentVariable(named = "PROCESSOR_ARCHITECTURE", matches = "AMD64")
    void testProcessorArchitecture() {
    }

    @Test
    @EnabledIfEnvironmentVariable(named = "ENVIRONMENT", matches = "dev")
    void testDevEnvironment() {
    }

    @Test
    @DisabledIfEnvironmentVariable(named = "ENVIRONMENT", matches = "prod")
    void testNoProdEnvironment() {
    }

    @DisplayName("Testing account name in development environment")
    @Test
    void testAccountNameInDevEnvironment() {
        boolean isDev = "dev".equals(System.getenv("ENVIRONMENT"));
        assumeTrue(isDev, "This test only runs in the 'dev' environment");

        // Arrange
        String person = "John";
        BigDecimal initialBalance = new BigDecimal("1000.00");
        Account account = new Account(person, initialBalance);

        // Act & Assert
        assertEquals(person, account.getPerson());
        assertEquals(17, account.getPerson().length());
        assertFalse(account.getPerson().isEmpty());
    }

    @DisplayName("Testing account name in development environment 2")
    @Test
    void testAccountNameDev2() {
        boolean isDev = "dev".equals(System.getProperty("ENVIRONMENT"));

        assumingThat(isDev, () -> {
            // Arrange
            String person = "John";
            BigDecimal balance = new BigDecimal("1000.00");

            Account account = new Account(person, balance);

            // Act & Assert
            assertEquals(person, account.getPerson());
            assertEquals(17, account.getPerson().length());
        });
        assertFalse(account.getPerson().isEmpty());
    }

    @Nested
    class OperatingSystemTests {
        @Test
        @EnabledOnOs(OS.WINDOWS)
        void testOnlyOnWindows() {
        }

        @Test
        @DisabledOnOs(OS.WINDOWS)
        void testNotOnWindows() {
        }
    }

    @DisplayName("Testing repeated debit account")
    @RepeatedTest(value = 5, name = "{displayName} - Repetition {currentRepetition} of {totalRepetitions}")
    void testRepeatedDebitAccount(RepetitionInfo info) {
        if (info.getCurrentRepetition() == 3) {
            System.out.println("We are in repetition " + info.getCurrentRepetition());
        }

        // Arrange
        String person = "John";
        BigDecimal initialBalance = new BigDecimal("1000.00");
        BigDecimal amount = new BigDecimal("100.00");

        Account account = new Account(person, initialBalance );

        // Act
        account.debit(amount);

        // Assert
        assertEquals(new BigDecimal("900.00"), account.getBalance());
        assertEquals("900.00", account.getBalance().toPlainString());
    }

    @ParameterizedTest(name = "Test {index} - Debiting with amount {0}")
    @ValueSource(strings = {"100", "200", "300", "500", "700", "1000"})
    void testParameterizedDebitAccount(String amount) {
        // Arrange
        Account account = new Account("John Doe", new BigDecimal("1000.00"));
        BigDecimal debitAmount = new BigDecimal(amount);

        // Act
        account.debit(debitAmount);

        // Assert
        assertNotNull(account.getBalance());
        assertTrue(account.getBalance().compareTo(BigDecimal.ZERO) >= 0);
    }

    @ParameterizedTest(name = "Test {index} - Debiting with amount {1}")
    @CsvSource({"1,100", "2,200", "3,300", "4,500", "5,700", "6,1000", "7,150", "8,200"})
    void testParameterizedDebitAccountCsvSource(String index, String amount) {
        System.out.println(index + " -> " + amount);
        // Arrange
        Account account = new Account("John Doe", new BigDecimal("1000.00"));
        BigDecimal debitAmount = new BigDecimal(amount);

        // Act
        account.debit(debitAmount);

        // Assert
        assertNotNull(account.getBalance());
        assertTrue(account.getBalance().compareTo(BigDecimal.ZERO) >= 0);
    }

    @ParameterizedTest(name = "Test {index} - Debiting with amount {0}")
    @CsvFileSource(resources = "/data.csv")
    void testParameterizedDebitAccountCsvFileSource(String amount) {
        // Arrange
        Account account = new Account("John Doe", new BigDecimal("1000.00"));
        BigDecimal debitAmount = new BigDecimal(amount);

        // Act
        account.debit(debitAmount);

        // Assert
        assertNotNull(account.getBalance());
        assertTrue(account.getBalance().compareTo(BigDecimal.ZERO) >= 0);
    }

    @ParameterizedTest(name = "Test {index} - Debiting with amount {0}")
    @MethodSource("amountList")
    void testParameterizedDebitAccountMethodSource(String amount) {
        // Arrange
        Account account = new Account("John Doe", new BigDecimal("1000.00"));
        BigDecimal debitAmount = new BigDecimal(amount);

        // Act
        account.debit(debitAmount);

        // Assert
        assertNotNull(account.getBalance());
        assertTrue(account.getBalance().compareTo(BigDecimal.ZERO) >= 0);
    }

    static List<String> amountList() {
        return Arrays.asList("100", "200", "300", "500", "700", "1000");
    }

    @ParameterizedTest(name = "number {index} executing with values {0},{1} - {argumentsWithNames}")
    @CsvSource({"200,100", "250,200", "300,300", "4000,500", "750,700", "1600,1000", "1700,1500", "8000,2000"})
    void testDebitAccountCsvSource2(String initialBalance, String amount) {
        Account account = new Account("John Doe", new BigDecimal(initialBalance));
        account.debit(new BigDecimal(amount));
        assertNotNull(account.getBalance());
        assertTrue(account.getBalance().compareTo(BigDecimal.ZERO) >= 0);
    }

    @ParameterizedTest(name = "number {index} executing with values {0},{1} - {argumentsWithNames}")
    @CsvSource({"200,100,John,John", "250,200,Pepe,Pepe", "300,300,Luis,Luis", "4000,500,Jose,Jose", "750,700,Carlos,Carlos", "1600,1000,Ana,Ana", "1700,1500,Julio,Julio", "8000,2000,Diego,Diego"})
    void testDebitAccountCsvSource3(String balance, String amount, String expected, String actual) {
        Account account = new Account("John Doe", new BigDecimal(balance));
        account.debit(new BigDecimal(amount));
        assertNotNull(account.getBalance());
        assertTrue(account.getBalance().compareTo(BigDecimal.ZERO) >= 0);
        assertEquals(expected, actual);
    }

    @Tag("param")
    @ParameterizedTest(name = "Test {index} - Debiting with balance {0}, amount {1}, expected {2}, actual {3}")
    @CsvFileSource(resources = "/data2.csv")
    void testParameterizedDebitAccountCsvFileSource2(String balance, String amount, String expected, String actual) {
        // Arrange
        Account account = new Account("John Doe", new BigDecimal(balance));
        BigDecimal debitAmount = new BigDecimal(amount);

        // Act
        account.debit(debitAmount);

        // Assert
        assertNotNull(account.getBalance());
        assertTrue(account.getBalance().compareTo(BigDecimal.ZERO) >= 0);
        assertEquals(expected, actual);
    }

    @Tag("info")
    @DisplayName("Testing the account name with TestInfo")
    @Test
    void testAccountNameInfo(TestInfo testInfo) {
        // Arrange
        String expectedName = "John Doe";
        Account account = new Account("John Doe", new BigDecimal("1000.00"));

        // Act
        String actualName = account.getPerson();

        // Assert
        System.out.println("Test method = " + testInfo.getTestMethod().orElse(null).getName());
        System.out.println("Test class = " + testInfo.getTestClass().orElse(null));
        System.out.println("Display name = " + testInfo.getDisplayName());

        if (testInfo.getTags().contains("info")) {
            System.out.println("Performing action with the 'info' tag");
        }

        assertFalse(actualName.isEmpty());
        assertEquals(expectedName, actualName);
    }

    @Tag("info")
    @DisplayName("Testing the account name with TestReporter")
    @Test
    void testAccountNameReporter(TestInfo testInfo, TestReporter testReporter) {
        testReporter.publishEntry("running: " + testInfo.getDisplayName() + " " + testInfo.getTestMethod().orElse(null).getName() + " " + testInfo.getTags());
        Account account = new Account("John Doe", new BigDecimal("1000.00"));
        if (testInfo.getTags().contains("info")) {
            testReporter.publishEntry("doing something with the info tag");
        }
        assertFalse(account.getPerson().isEmpty());
        assertEquals("John Doe", account.getPerson());
    }

    @Nested
    @Tag("timeout")
    class TestsTimeout {
        @Test
        @Timeout(5)
        void testMethodTimeout() throws InterruptedException {
            TimeUnit.SECONDS.sleep(2);
        }

        @Test
        @Timeout(value = 2000, unit = TimeUnit.MILLISECONDS)
        void testMethodTimeout2() throws InterruptedException {
            TimeUnit.SECONDS.sleep(1);
        }

        @Test
        void testMethodTimeoutAssertions() {
            assertTimeout(Duration.ofSeconds(5), () -> TimeUnit.MILLISECONDS.sleep(2000));
        }
    }
}