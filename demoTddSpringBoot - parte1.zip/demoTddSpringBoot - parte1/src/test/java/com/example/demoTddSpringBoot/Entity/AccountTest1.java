package com.example.demoTddSpringBoot.Entity;

import com.example.demoTddSpringBoot.Exceptions.InsufficientMoneyException;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class AccountTest1 {
    @Test
    void testAccountNameIsValid() {
        // Arrange
        Account account = new Account("John", new BigDecimal("1000.00"));

        // Act & Assert
        assertEquals("John", account.getPerson());
        assertEquals(4, account.getPerson().length());
        assertFalse(account.getPerson().isEmpty());
    }

    @Test
    void testAccountBalance() {
        // Arrange
        BigDecimal initialBalance = new BigDecimal("1000.00");
        Account account = new Account("John", initialBalance);

        // Act & Assert
        assertEquals(initialBalance, account.getBalance());
        assertEquals(1000.00, account.getBalance().doubleValue());
        assertEquals(initialBalance.doubleValue(), account.getBalance().doubleValue());
        assertTrue(account.getBalance().compareTo(BigDecimal.ZERO) > 0);
        assertFalse(account.getBalance().compareTo(BigDecimal.ZERO) < 0);
    }

    @Test
    void testDebitAccount() {
        // Arrange
        BigDecimal initialBalance = new BigDecimal("1000.00");
        Account account = new Account("John", initialBalance);

        // Act
        BigDecimal debitAmount = new BigDecimal("100.00");
        account.debit(debitAmount);

        // Assert
        BigDecimal expectedBalance = initialBalance.subtract(debitAmount);
        assertEquals(expectedBalance, account.getBalance());
        assertEquals("900.00", account.getBalance().toPlainString());
        assertEquals(expectedBalance.toPlainString(), account.getBalance().toPlainString());
    }

    @Test
    void testCreditAccount() {
        // Arrange
        BigDecimal initialBalance = new BigDecimal("1000.00");
        Account account = new Account("John", initialBalance);

        // Act
        BigDecimal creditAmount = new BigDecimal("100.00");
        account.credit(creditAmount);

        // Assert
        BigDecimal expectedBalance = initialBalance.add(creditAmount);
        assertEquals(expectedBalance, account.getBalance());
        assertEquals("1100.00", account.getBalance().toPlainString());
        assertEquals(expectedBalance.toPlainString(), account.getBalance().toPlainString());
    }

    @Test
    void testInsufficientMoneyException() {
        // Arrange
        BigDecimal initialBalance = new BigDecimal("1000.00");
        Account account = new Account("John", initialBalance);

        // Act & Assert
        Exception exception = assertThrows(InsufficientMoneyException.class, () -> account.debit(new BigDecimal("1500.00")));
        String expectedMessage = "Insufficient funds in the account";
        String actualMessage = exception.getMessage();
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    void testTransferMoneyBetweenAccounts() {
        // Arrange
        BigDecimal initialBalance1 = new BigDecimal("5000.00");
        Account account1 = new Account("John", initialBalance1);

        BigDecimal initialBalance2 = new BigDecimal("1000.00");
        Account account2 = new Account("Doe", initialBalance2);

        Bank bank = new Bank();
        bank.setName("Banco de Chile");

        // Act
        BigDecimal transferAmount = new BigDecimal("500.00");
        bank.transfer(account1, account2, transferAmount);

        // Assert
        assertEquals(new BigDecimal("4500.00"), account1.getBalance());
        assertEquals(initialBalance1.subtract(transferAmount), account1.getBalance());
        assertEquals(new BigDecimal("1500.00"), account2.getBalance());
        assertEquals(initialBalance2.add(transferAmount), account2.getBalance());
    }

    @Test
    void testAccountBankRelationship() {
        //fail();
        // Arrange
        BigDecimal initialBalance1 = new BigDecimal("5000.00");
        Account account1 = new Account("John", initialBalance1);

        BigDecimal initialBalance2 = new BigDecimal("1000.00");
        Account account2 = new Account("Doe", initialBalance2);

        Bank bank = new Bank();
        bank.setName("Banco de Chile");
        bank.addAccount(account1);
        bank.addAccount(account2);

        // Act
        bank.transfer(account1, account2, new BigDecimal("500.00"));

        // Assert
        assertEquals(new BigDecimal("4500.00"), account1.getBalance());
        assertEquals(new BigDecimal("1500.00"), account2.getBalance());

        assertEquals(2, bank.getAccounts().size());
        assertEquals("Banco de Chile", account1.getBank().getName());
        assertEquals("Banco de Chile", account2.getBank().getName());
        assertEquals("John", bank.getAccounts().stream()
                .filter(c -> c.getPerson().equals("John"))
                .findFirst()
                .get()
                .getPerson());
        assertTrue(bank.getAccounts().stream()
                .anyMatch(c -> c.getPerson().equals("John")));
        assertTrue(bank.getAccounts().stream()
                .anyMatch(c -> c.getPerson().equals("Doe")));
    }

    @Test
    void testBankAccountRelationshipAll() {
        // Arrange
        Account account1 = new Account("John", new BigDecimal("5000.00"));
        Account account2 = new Account("Doe", new BigDecimal("1000.00"));

        Bank bank = new Bank();
        bank.setName("Banco de Chile");
        bank.addAccount(account1);
        bank.addAccount(account2);

        // Act
        bank.transfer(account1, account2, new BigDecimal("500.00"));

        // Assert
        assertAll(
                () -> assertEquals(new BigDecimal("4500.00"), account1.getBalance()),
                () -> assertEquals(new BigDecimal("1500.00"), account2.getBalance()),
                () -> assertEquals(2, bank.getAccounts().size()),
                () -> assertEquals("Banco de Chile", account1.getBank().getName()),
                () -> assertEquals("Banco de Chile", account2.getBank().getName()),
                () -> assertEquals("John", bank.getAccounts().stream()
                        .filter(c -> c.getPerson().equals("John"))
                        .findFirst()
                        .get()
                        .getPerson()),
                () -> assertTrue(bank.getAccounts().stream()
                        .anyMatch(c -> c.getPerson().equals("John"))),
                () -> assertTrue(bank.getAccounts().stream()
                        .anyMatch(c -> c.getPerson().equals("Doe"))));
    }

    @Test
    @DisplayName("Testing relationships between accounts and the bank with assertAll")
    void testBankAccountRelationshipAll2() {
        // Arrange
        Account account1 = new Account("John", new BigDecimal("5000.00"));
        Account account2 = new Account("Doe", new BigDecimal("1000.00"));

        Bank bank = new Bank();
        bank.setName("Banco de Chile");
        bank.addAccount(account1);
        bank.addAccount(account2);

        // Act
        bank.transfer(account1, account2, new BigDecimal("500.00"));

        // Assert
        assertAll(
                () -> assertEquals(new BigDecimal("4500.00"), account1.getBalance(), "The value of the account1 balance is not as expected"),
                () -> assertEquals(new BigDecimal("1500.00"), account2.getBalance(), "The value of the account2 balance is not as expected"),
                () -> assertEquals(2, bank.getAccounts().size(), "The bank account list has not the expected size"),
                () -> assertEquals("Banco de Chile", account1.getBank().getName(), "The name of the bank is not the expected"),
                () -> assertEquals("Banco de Chile", account2.getBank().getName(), "The name of the bank is not the expected"),
                () -> assertEquals("John", bank.getAccounts().stream()
                        .filter(c -> c.getPerson().equals("John"))
                        .findFirst()
                        .get()
                        .getPerson(), "The account holder name is not the expected"),
                () -> assertTrue(bank.getAccounts().stream()
                        .anyMatch(c -> c.getPerson().equals("John")), "The account holder name is not the expected"),
                () -> assertTrue(bank.getAccounts().stream()
                        .anyMatch(c -> c.getPerson().equals("Doe")), "The account holder name is not the expected"));
    }

    @Test
    @Disabled("Test temporarily disabled due to code changes")
    @DisplayName("Testing relationships between accounts and the bank with assertAll")
    void testAccountBankRelationshipWithAssertAll2() {
        // Arrange
        BigDecimal initialBalance1 = new BigDecimal("5000.00");
        Account account1 = new Account("John", initialBalance1);

        BigDecimal initialBalance2 = new BigDecimal("1000.00");
        Account account2 = new Account("Mary", initialBalance2);

        Bank bank = new Bank();
        bank.setName("Banco de Chile");

        bank.addAccount(account1);
        bank.addAccount(account2);

        // Act
        bank.transfer(account1, account2, new BigDecimal("500.00"));

        // Assert
        assertAll(
                () -> assertEquals(new BigDecimal("4500.00"), account1.getBalance()),
                () -> assertEquals(new BigDecimal("1500.00"), account2.getBalance()),
                () -> assertEquals("Banco de Chile", account1.getBank().getName()),
                () -> assertEquals("Banco de Chile", account2.getBank().getName())

        );
    }
}