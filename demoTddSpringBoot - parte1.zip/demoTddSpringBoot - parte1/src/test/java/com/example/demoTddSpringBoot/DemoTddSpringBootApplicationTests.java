package com.example.demoTddSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoTddSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
