package com.example.demoTddSpringBoot.Service;

import com.example.demoTddSpringBoot.Data;
import com.example.demoTddSpringBoot.Entity.Exam;
import com.example.demoTddSpringBoot.Repository.ExamRepositoryImpl;
import com.example.demoTddSpringBoot.Repository.QuestionRepositoryImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ExamServiceImplTest2 {
    @Spy
    ExamRepositoryImpl examRepository;
    @Spy
    QuestionRepositoryImpl questionRepository;
    @InjectMocks
    ExamServiceImpl examService;

    @Test
    void testFindExamByNameWithSpyHybrid() {
        // Arrange
        doReturn(Data.QUESTIONS).when(questionRepository).findQuestionsByExamId(anyLong());

        // Act
        Exam exam = examService.findExamByNameWithQuestions("Mathematics");

        // Assert
        assertEquals(1L, exam.getId());
        assertEquals("Mathematics", exam.getName());
        assertEquals(5, exam.getQuestions().size());
        assertTrue(exam.getQuestions().contains("question1"));
        verify(examRepository).findAll(); // Real
        verify(questionRepository).findQuestionsByExamId(anyLong()); // Stub
    }
}
