package com.example.demoTddSpringBoot.Service;

import com.example.demoTddSpringBoot.Entity.Exam;
import com.example.demoTddSpringBoot.Repository.ExamRepository;
import com.example.demoTddSpringBoot.Repository.ExamRepositoryImpl;
import com.example.demoTddSpringBoot.Repository.QuestionRepository;
import com.example.demoTddSpringBoot.Repository.QuestionRepositoryImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.Answer;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import com.example.demoTddSpringBoot.Data;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ExamServiceImplTest {
    @Mock
    ExamRepositoryImpl examRepository;
    @Mock
    QuestionRepositoryImpl questionRepository;
    @InjectMocks
    ExamServiceImpl examService;

    @BeforeEach
    void setUp() {
        /*
        examRepository = mock(ExamRepository.class);
        questionRepository = mock(QuestionRepository.class);
        examService = new ExamServiceImpl(examRepository, questionRepository);
         */
    }

    @Test
    void testFindExamByName() {
        // Arrange
        ExamRepository examRepository = new ExamRepositoryImpl();
        ExamService examService = new ExamServiceImpl(examRepository);

        // Act
        Optional<Exam> exam = examService.findExamByName("Mathematics");

        // Assert
        assertTrue(exam.isPresent(), "Expected exam to be found");
        assertEquals(1L, exam.orElseThrow().getId(), "Exam ID should match");
        assertEquals("Mathematics", exam.orElseThrow().getName(), "Exam name should match");
    }

    @Test
    void testFindExamByNameNotFound() {
        // Arrange
        ExamRepository examRepository = new ExamRepositoryImpl();
        ExamService examService = new ExamServiceImpl(examRepository);

        // Act
        Optional<Exam> exam = examService.findExamByName("MathematicsNotFound");

        // Assert
        assertFalse(exam.isPresent(), "Expected exam to be found");
    }

    @Test
    void testFindExamByNameWithMock() {
        // Arrange
        List<Exam> data = Arrays.asList(
                    new Exam(1L, "Mathematics"),
                    new Exam(2L, "Arithmetic"),
                    new Exam(3L, "Trigonometry")
        );

        when(examRepository.findAll()).thenReturn(data);

        // Act
        Optional<Exam> exam = examService.findExamByName("Mathematics");

        // Assert
        assertTrue(exam.isPresent(), "Expected exam to be found");
        assertEquals(1L, exam.orElseThrow().getId(), "Exam ID should match");
        assertEquals("Mathematics", exam.orElseThrow().getName(), "Exam name should match");
    }

    @Test
    void testFindExamByNameWithMockEmptyList() {
        // Arrange
        List<Exam> data = Collections.emptyList();

        when(examRepository.findAll()).thenReturn(data);

        // Act
        Optional<Exam> exam = examService.findExamByName("MathematicsNotFound");

        // Assert
        assertFalse(exam.isPresent(), "Expected exam to be found");
    }

    @Test
    void testQuestionsInExam() {
        // Arrange
        when(examRepository.findAll()).thenReturn(Data.EXAMS);
        when(questionRepository.findQuestionsByExamId(anyLong())).thenReturn(Data.QUESTIONS);

        // Act
        Exam exam = examService.findExamByNameWithQuestions("Mathematics");

        // Assert
        assertEquals(5, exam.getQuestions().size());
        assertTrue(exam.getQuestions().contains("question1"));
    }

    @Test
    void testQuestionsInExamWithVerify() {
        // Arrange
        when(examRepository.findAll()).thenReturn(Data.EXAMS);
        when(questionRepository.findQuestionsByExamId(anyLong())).thenReturn(Data.QUESTIONS);

        // Act
        Exam exam = examService.findExamByNameWithQuestions("Mathematics");

        // Assert
        assertEquals(5, exam.getQuestions().size());
        assertTrue(exam.getQuestions().contains("question1"));
        verify(examRepository).findAll();
        verify(questionRepository).findQuestionsByExamId(anyLong());
    }

    @Test
    void testQuestionsInExamWithVerify2() {
        // Arrange
        when(examRepository.findAll()).thenReturn(Collections.emptyList());
        //when(questionRepository.findQuestionsByExamId(anyLong())).thenReturn(Data.QUESTIONS);

        // Act
        Exam exam = examService.findExamByNameWithQuestions("Mathematics");

        // Assert
        assertNull(exam);
        verify(examRepository).findAll();
        verify(examRepository, times(1)).findAll();
        verify(questionRepository, never()).findQuestionsByExamId(anyLong());
    }

    @Test
    void testSaveExam() {
        // Arrange
        Exam newExam = Data.EXAM;
        newExam.setQuestions(Data.QUESTIONS);

        when(examRepository.save(any(Exam.class))).thenReturn(Data.EXAM);

        // Act
        Exam exam = examService.save(newExam);

        // Assert
        assertNotNull(exam, "Exam should not be null");
        assertEquals(4L, exam.getId(), "Exam ID should match");
        assertEquals("Physics", exam.getName(), "Exam name should match");
        verify(examRepository).save(any(Exam.class));
        verify(questionRepository).saveMany(anyList());
    }

    @Test
    void testSaveExamWithAnswer() {
        // Arrange
        Exam newExam = Data.EXAM;
        newExam.setQuestions(Data.QUESTIONS);

        //when(examRepository.save(any(Exam.class))).thenReturn(Data.EXAM);
        when(examRepository.save(any(Exam.class))).then(new Answer<Exam>() {
            Long idSequence = 4L;
            @Override
            public Exam answer(InvocationOnMock invocation) throws Throwable {
                Exam exam = invocation.getArgument(0);
                exam.setId(++idSequence);
                exam.setName("Custom " + exam.getName());
                return exam;
            }
        });

        // Act
        Exam exam = examService.save(newExam);

        // Assert
        assertNotNull(exam, "Exam should not be null");
        assertEquals(5L, exam.getId(), "Exam ID should match");
        assertEquals("Custom Physics", exam.getName(), "Exam name should match");
        verify(examRepository).save(any(Exam.class));
        verify(questionRepository).saveMany(anyList());
    }

    @Test
    void testException() {
        // Arrange
        when(examRepository.findAll()).thenReturn(Data.EXAMS_ID_NULL);
        when(questionRepository.findQuestionsByExamId(isNull())).thenThrow(IllegalArgumentException.class);

        // Act
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            examService.findExamByNameWithQuestions("Mathematics");
        });
        assertEquals(IllegalArgumentException.class, exception.getClass(), "Exception should be IllegalArgumentException");
        verify(examRepository).findAll();
        verify(questionRepository).findQuestionsByExamId(isNull());
    }

    @Test
    void testArgumentMatchers() {
        // Arrange
        when(examRepository.findAll()).thenReturn(Data.EXAMS);
        when(questionRepository.findQuestionsByExamId(anyLong())).thenReturn(Data.QUESTIONS);

        // Act
        Exam exam = examService.findExamByNameWithQuestions("Mathematics");

        // Assert
        verify(examRepository).findAll();
        verify(questionRepository).findQuestionsByExamId(1L); // Literal
        verify(questionRepository).findQuestionsByExamId(eq(1L));
        verify(questionRepository).findQuestionsByExamId(any(Long.class));
        verify(questionRepository).findQuestionsByExamId(argThat(id -> id != null && id > 0));
    }

    @Test
    void testArgumentMatchersCustom() {
        // Arrange
        when(examRepository.findAll()).thenReturn(Data.EXAMS);
        when(questionRepository.findQuestionsByExamId(anyLong())).thenReturn(Data.QUESTIONS);

        // Act
        Exam exam = examService.findExamByNameWithQuestions("Mathematics");

        // Assert
        verify(examRepository).findAll();
        verify(questionRepository).findQuestionsByExamId(argThat(new MyArgsMatcher()));
    }

    public static class MyArgsMatcher implements ArgumentMatcher<Long> {
        private Long argument;

        @Override
        public boolean matches(Long argument) {
            this.argument = argument;
            return argument != null && argument > 0;
        }

        @Override
        public String toString() {
            return "MY CUSTOM ARGUMENT MATCHER";
        }
    }

    @Test
    void testArgumentCaptor() {
        // Arrange
        when(examRepository.findAll()).thenReturn(Data.EXAMS);

        examService.findExamByNameWithQuestions("Mathematics");
        ArgumentCaptor<Long> captor = ArgumentCaptor.forClass(Long.class);

        // Assert
        verify(questionRepository).findQuestionsByExamId(captor.capture());
        assertEquals(1L, captor.getValue());
    }

    @Captor
    ArgumentCaptor<Long> captor;

    @Test
    void testArgumentCaptor2() {
        // Arrange
        when(examRepository.findAll()).thenReturn(Data.EXAMS);

        examService.findExamByNameWithQuestions("Mathematics");

        // Assert
        verify(questionRepository).findQuestionsByExamId(captor.capture());
        assertEquals(1L, captor.getValue());
    }

    @Test
    void testDoThrow() {
        // Arrange
        Exam exam = Data.EXAM;
        exam.setQuestions(Data.QUESTIONS);
        doThrow(IllegalArgumentException.class).when(questionRepository).saveMany(anyList());

        // Act
        assertThrows(IllegalArgumentException.class, () -> {
            examService.save(exam);
        });
    }

    @Test
    void testDoAnswer() {
        // Arrange
        when(examRepository.findAll()).thenReturn(Data.EXAMS);
        doAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            return id == 1L ? Data.QUESTIONS : Collections.emptyList();
        }).when(questionRepository).findQuestionsByExamId(anyLong());

        // Act
        Exam exam = examService.findExamByNameWithQuestions("Mathematics");

        // Assert
        assertEquals(5, exam.getQuestions().size());
        assertTrue(exam.getQuestions().contains("question1"));
    }

    @Test
    void testDoCallRealMethod() {
        // Arrange
        when(examRepository.findAll()).thenReturn(Data.EXAMS);
        //when(questionRepository.findQuestionsByExamId(anyLong())).thenReturn(Data.QUESTIONS);
        doCallRealMethod().when(questionRepository).findQuestionsByExamId(anyLong());

        // Act
        Exam exam = examService.findExamByNameWithQuestions("Mathematics");

        // Assert
        assertEquals(1L, exam.getId());
        assertEquals("Mathematics", exam.getName());
    }

    @Test
    void testFindExamByNameWithSpy() {
        // Arrange
        //ExamRepository examRepository = examRepository = mock(ExamRepository.class);
        ExamRepository examRepository = spy(ExamRepositoryImpl.class);
        QuestionRepository questionRepository = spy(QuestionRepositoryImpl.class);
        ExamService examService = new ExamServiceImpl(examRepository, questionRepository);

        // Act
        Exam exam = examService.findExamByNameWithQuestions("Mathematics");

        // Assert
        assertEquals(1L, exam.getId());
        assertEquals("Mathematics", exam.getName());
        assertEquals(5, exam.getQuestions().size());
        assertTrue(exam.getQuestions().contains("question1"));
    }

    @Test
    void testFindExamByNameWithSpyHybrid() {
        // Arrange
        ExamRepository examRepository = spy(ExamRepositoryImpl.class);
        QuestionRepository questionRepository = spy(QuestionRepositoryImpl.class);
        ExamService examService = new ExamServiceImpl(examRepository, questionRepository);

        doReturn(Data.QUESTIONS).when(questionRepository).findQuestionsByExamId(anyLong());

        // Act
        Exam exam = examService.findExamByNameWithQuestions("Mathematics");

        // Assert
        assertEquals(1L, exam.getId());
        assertEquals("Mathematics", exam.getName());
        assertEquals(5, exam.getQuestions().size());
        assertTrue(exam.getQuestions().contains("question1"));
        verify(examRepository).findAll(); // Real
        verify(questionRepository).findQuestionsByExamId(anyLong()); // Stub
    }

    @Test
    void testInvocationOrden() {
        // Arrange
        when(examRepository.findAll()).thenReturn(Data.EXAMS);

        // Act
        examService.findExamByNameWithQuestions("Mathematics");
        examService.findExamByNameWithQuestions("Arithmetic");

        // Assert
        InOrder inOrder = inOrder(questionRepository);

        inOrder.verify(questionRepository).findQuestionsByExamId(1L);
        inOrder.verify(questionRepository).findQuestionsByExamId(2L);
    }

    @Test
    void testQuestionsInExamWithVerify3() {
        // Arrange
        when(examRepository.findAll()).thenReturn(Data.EXAMS);

        // Act
        Exam exam = examService.findExamByNameWithQuestions("Mathematics");

        // Assert
        verify(questionRepository).findQuestionsByExamId(1L);
        verify(questionRepository, times(1)).findQuestionsByExamId(1L);
        verify(questionRepository, atLeastOnce()).findQuestionsByExamId(1L);
        verify(questionRepository, atLeast(1)).findQuestionsByExamId(anyLong());
        verify(questionRepository, atMostOnce()).findQuestionsByExamId(anyLong());
        verify(questionRepository, atMost(1)).findQuestionsByExamId(anyLong());

    }
}
