package com.example.demoTddSpringBoot;

import com.example.demoTddSpringBoot.Entity.Exam;

import java.util.Arrays;
import java.util.List;

public class Data {
    public final static List<Exam> EXAMS = Arrays.asList(
            new Exam(1L, "Mathematics"),
            new Exam(2L, "Arithmetic"),
            new Exam(3L, "Trigonometry")
    );

    public final static List<Exam> EXAMS_ID_NULL = Arrays.asList(
            new Exam(null, "Mathematics"),
            new Exam(null, "Arithmetic"),
            new Exam(null, "Trigonometry")
    );

    public final static List<String> QUESTIONS = Arrays.asList(
            "question1", "question2", "question3", "question4", "question5"
    );

    public final static Exam EXAM = new Exam(4L, "Physics");
}
