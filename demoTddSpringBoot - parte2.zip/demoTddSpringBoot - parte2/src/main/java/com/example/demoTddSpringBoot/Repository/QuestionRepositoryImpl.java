package com.example.demoTddSpringBoot.Repository;

import com.example.demoTddSpringBoot.Data;
import com.example.demoTddSpringBoot.Repository.QuestionRepository;

import java.util.List;

public class QuestionRepositoryImpl implements QuestionRepository {
    @Override
    public List<String> findQuestionsByExamId(Long id) {
        System.out.println("REAL QuestionRepositoryImpl.findQuestionsByExamId");
        return Data.QUESTIONS;
    }

    @Override
    public void saveMany(List<String> questions) {

    }
}
