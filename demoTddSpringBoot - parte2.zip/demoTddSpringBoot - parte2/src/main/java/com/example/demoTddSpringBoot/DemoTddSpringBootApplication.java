package com.example.demoTddSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoTddSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoTddSpringBootApplication.class, args);
	}

}
