package com.example.demoTddSpringBoot.Service;

import com.example.demoTddSpringBoot.Entity.Exam;
import com.example.demoTddSpringBoot.Repository.ExamRepository;
import com.example.demoTddSpringBoot.Repository.QuestionRepository;

import java.util.List;
import java.util.Optional;

public class ExamServiceImpl implements ExamService {
    private ExamRepository examRepository;
    private QuestionRepository questionRepository;

    public ExamServiceImpl(ExamRepository examRepository) {
        this.examRepository = examRepository;
    }

    public ExamServiceImpl(ExamRepository examRepository, QuestionRepository questionRepository) {
        this.examRepository = examRepository;
        this.questionRepository = questionRepository;
    }

    @Override
    public Optional<Exam> findExamByName(String name) {
        return examRepository.findAll()
                .stream()
                .filter(e -> e.getName().contains(name))
                .findFirst();
    }

    @Override
    public Exam findExamByNameWithQuestions(String name) {
        Optional<Exam> examenOptional = findExamByName(name);
        if (examenOptional.isPresent()) {
            Exam exam = examenOptional.get();
            List<String> questions = questionRepository.findQuestionsByExamId(exam.getId());
            exam.setQuestions(questions);
            return exam;
        }
        return null;
    }

    @Override
    public Exam save(Exam exam) {
        if (exam.getQuestions() != null && !exam.getQuestions().isEmpty()) {
            questionRepository.saveMany(exam.getQuestions());
        }
        return examRepository.save(exam);
    }
}
