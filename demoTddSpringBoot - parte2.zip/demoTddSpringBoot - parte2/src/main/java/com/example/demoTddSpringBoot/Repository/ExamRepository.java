package com.example.demoTddSpringBoot.Repository;

import com.example.demoTddSpringBoot.Entity.Exam;

import java.util.List;

public interface ExamRepository {
    List<Exam> findAll();
    Exam save(Exam exam);
}
