package com.example.demoTddSpringBoot.Repository;

import com.example.demoTddSpringBoot.Entity.Exam;
import com.example.demoTddSpringBoot.Repository.ExamRepository;

import java.util.Arrays;
import java.util.List;

public class ExamRepositoryImpl implements ExamRepository {
    @Override
    public List<Exam> findAll() {
        return Arrays.asList(
                new Exam(1L, "Mathematics"),
                new Exam(2L, "Arithmetic"),
                new Exam(3L, "Trigonometry"));
    }

    @Override
    public Exam save(Exam exam) {
        return null;
    }
}
