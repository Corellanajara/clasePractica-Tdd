package com.example.demoTddSpringBoot.Repository;

import java.util.List;

public interface QuestionRepository {
    List<String> findQuestionsByExamId(Long id);
    void saveMany(List<String> questions);
}
